# Weapon detection Server Side
 
