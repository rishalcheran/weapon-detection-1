from django.apps import AppConfig

class AlertuploadRestConfig(AppConfig):
    name = 'alertupload_rest'
