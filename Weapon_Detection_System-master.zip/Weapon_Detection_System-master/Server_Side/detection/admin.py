from django.contrib import admin

from detection.models import UploadAlert

# Register your models here.
admin.site.register(UploadAlert)